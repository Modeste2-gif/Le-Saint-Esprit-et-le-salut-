const mongoose = require("mongoose");
const TeachingSchema = new mongoose.Schema({
  titre: String,
  contenu: String,
  theme: String,
  date: { type: Date, default: Date.now },
});
module.exports = mongoose.model("Teaching", TeachingSchema);
