const express = require("express");
const router = express.Router();
const Teaching = require("../models/Teaching");

router.get("/", async (req, res) => {
  const teachings = await Teaching.find();
  res.json(teachings);
});

router.post("/", async (req, res) => {
  const { titre, contenu, theme } = req.body;
  const teaching = new Teaching({ titre, contenu, theme });
  await teaching.save();
  res.json({ message: "Enseignement enregistré ✅" });
});

module.exports = router;
