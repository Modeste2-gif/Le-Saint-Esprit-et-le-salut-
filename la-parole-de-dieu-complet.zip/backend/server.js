const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const teachingRoutes = require("./routes/teachings");
require("dotenv").config();

app.use(cors());
app.use(express.json());
app.use("/api/enseignements", teachingRoutes);

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.listen(5000, () => {
  console.log("Serveur backend démarré sur le port 5000 ✅");
});
