import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Teachings from "./pages/Teachings";
import Verses from "./pages/Verses";
import Devotions from "./pages/Devotions";
import Admin from "./pages/Admin";
import Login from "./pages/Login";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/enseignements" element={<Teachings />} />
        <Route path="/versets" element={<Verses />} />
        <Route path="/meditations" element={<Devotions />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
