import React from "react";

export default function Home() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold mb-4">La Parole de Dieu</h1>
      <p className="text-gray-700">Bienvenue dans votre bibliothèque spirituelle. Explorez les enseignements, les versets et les méditations quotidiennes.</p>
    </div>
  );
}
